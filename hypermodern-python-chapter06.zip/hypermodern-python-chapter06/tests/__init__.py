"""Test suite for the hypermodern_python package."""
