# hypermodern-python

Companion repository for the Hypermodern Python article series<br>
https://medium.com/@cjolowicz/hypermodern-python-d44485d9d769
