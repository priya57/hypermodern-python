"""The hypermodern Python project."""
__version__ = "0.1.0"
